﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex2_Carlos
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double aresta;
            double resultado;
            
            Console.WriteLine("Exercicio 2");
            Console.WriteLine("");

            Console.WriteLine("digite o tamanho da aresta");
            aresta = double.Parse(Console.ReadLine());

            Console.WriteLine("Resultado da: ");
            resultado = aresta * aresta;
            Console.WriteLine(resultado);
        }
    }
}
