﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista_de_exercicios
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double nbase;
            double altura;
            double resultado;

            Console.WriteLine("Digite o valor da Base:  ");
            nbase = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o valor da altura:  ");
            altura = double.Parse(Console.ReadLine());

            resultado = nbase * altura;

            Console.WriteLine("Resultado: {0}",resultado) ;

        }
    }
}
