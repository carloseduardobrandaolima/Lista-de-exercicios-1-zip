﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex11_lista
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            double nbase;
            double expoente;
            double resultado;
            Console.WriteLine("Exercício 11"); Console.WriteLine("");
            Console.Write("Digite o Valor da Base: "); 
            nbase = double.Parse(Console.ReadLine());
            Console.Write("Digite o Valor do Expoente: "); 
            expoente = double.Parse(Console.ReadLine());
            resultado = Math.Pow(nbase, expoente); Console.WriteLine(resultado);


        }
    }
}
