﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EXERCICIO_4_lista
{
    internal class Program
    {
        static void Main(string[] args)
        {

           
            double nbase; 
            double altura;
            double resultado;
            Console.WriteLine("Exercício 4 "); Console.WriteLine("");
            Console.Write("Digite o valor da Base: ");
            nbase = double.Parse(Console.ReadLine());
            Console.Write("Digite o valor da Altura: "); 
            altura = double.Parse(Console.ReadLine());
            resultado = (nbase * altura) / 2;
            Console.WriteLine(resultado);


        }
    }
}
